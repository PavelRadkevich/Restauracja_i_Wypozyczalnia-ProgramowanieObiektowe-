#ifndef MATH_HELPERS_H
#define MATH_HELPERS_H  

unsigned long long factorial(unsigned int n);
#endif
