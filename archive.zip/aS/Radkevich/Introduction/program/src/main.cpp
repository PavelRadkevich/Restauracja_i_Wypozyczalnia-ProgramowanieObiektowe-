#include <iostream>
#include "math_helpers.h"
using namespace std;

int main()
{
    cout << "Hello world!" << endl;
    cout << factorial(5) << endl;
    return 0;
}

