//
// Created by student on 03.06.2022.
//

#ifndef RESTAURANT_GROUP_H
#define RESTAURANT_GROUP_H


class Group {

};


#endif //RESTAURANT_GROUP_H
